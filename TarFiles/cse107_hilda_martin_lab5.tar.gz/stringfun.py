def ends(s):
    """Find and return the the first two and the last two characters
    of the string. When the input is only 2 characters long,
    the program will return them as firs and last.
    Fro example: Do will be return as DODO.
    I did it like this because it is not specified otherwise.
    """
    return s[:2] + s[-2:]


def mix(a, b):
    """The first two characters of each word swapped with the other
    word’s first two characters.
    """
    new_a = b[:2] + a[2:]
    new_b = a[:2] + b[2:]
    """Find and return the the first two and
    the new a and b."""
    return new_a + ' ' + new_b


def main():
    """The main function uses the functions, the input() function,
    and the print() function.

    The ends() function takes in a string from the user and
    prints just the first two and the last two characters of the string.
    It assumed that the user will input a string with
    at least 2 characters long.

    The mix() function takes two strings a and b and prints
    the two strings concatenated, but with the first two characters of
    each word swapped with the other word’s first two characters.
    It assumed that the user will input a string with
    at least 2 characters long.
    """
    print('== ends ==')
    # Prompts for user's input.
    s = input('Enter a string >>>')
    # Calls end
    print(ends(s))
    print('== mix ==')
    # Prompts for user's input.
    a = input('String a >>>')
    # Prompts for user's input.
    b = input('String b >>>')
    # Call mix
    print(mix(a, b))

# Calling main.
if __name__ == "__main__":
        main()
