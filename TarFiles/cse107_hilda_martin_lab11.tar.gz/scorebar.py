import numpy as np
import matplotlib.pyplot as plt


def main():
    '''This function contains all the tools imported with
    matplotlib to plt the data. i made some random number because
    the provided data was too big
    '''
    N = 5
    act_composite = (20, 35, 30, 35, 27)
    act_total = (25, 32, 34, 20, 25)
    compo = (2, 3, 4, 1, 2)
    total = (3, 5, 2, 3, 3)
    ind = np.arange(N)    # The locations for the groups.
    width = 0.35       # the width of the bars.
    p1 = plt.bar(ind, act_composite, width, yerr=compo)
    p2 = plt.bar(ind, act_total, width,
                 bottom=act_composite, yerr=total)
    plt.ylabel('Scores')
    plt.title('Comparision of the ACT Scores')
    plt.xticks(ind, ('AK', 'AL', 'AR', 'AZ', 'CA'))  # Labels
    plt.yticks(np.arange(0, 81, 10))
    plt.legend((p1[0], p2[0]), ('ACT Composite', 'ACT Total'))
    plt.show()

if __name__ == '__main__':  # Main
    main()