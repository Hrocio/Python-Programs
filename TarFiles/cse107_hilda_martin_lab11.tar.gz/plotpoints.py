import matplotlib.pyplot as plt
xs = range(-5,15)
ys = [-(x-2)**2 for x in xs]

def main():
    '''This function plots the point xs and ys. It contains the plot
    for Plot of -(x - 2)^2 with labels, title,
    and an annotation. The annotation contains the text “max” and is
    located at the point (2, 20).
    '''
    plt.clf()
    plt.plot(xs, ys, 'b--')  # Points to plot.
    # Axis labels.
    plt.xlabel('X-axis')
    plt.ylabel('Y-axis')
    # Annotation.
    plt.annotate('max', xy=(2, 0), xytext=(2, -20), arrowprops=dict
                    (color='black', width =2,headwidth=6,headlength=8))
    plt.ylim([-160,0])
    plt.xlim([-5,15])
    plt.title('Plot of $-(x - 2)^2$')  # Title.
    plt.show()

if __name__ == '__main__':  # Main
    main()
